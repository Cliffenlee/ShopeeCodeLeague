import numpy as np
import pandas as pd
import collections
import csv

# read the dataset 
contacts = pd.read_json('./contacts.json')
contacts.tail()

resultDict = {}

def write_to_csv(orderedDict):
    # field names  
    fields = ['ticket_id', 'ticket_trace']  
        
    # data rows of csv file  
    rows = []
    
    for i in range(3):
        # print(f"iteration {i}", orderedDict)
        trace = orderedDict[i][0]
        contactCount = orderedDict[i][1]
        # print("what is this", trace)
        # print("what type is this", type(trace))
        trace = '-'.join(map(str, trace))
        trace += ", " + contactCount
        row = [i, trace]
        rows.append(row)
        
    # name of csv file  
    filename = "#1-YeetCode-Student.csv"
        
    # writing to csv file  
    with open(filename, 'w') as csvfile:  
        # creating a csv writer object  
        csvwriter = csv.writer(csvfile)  
            
        # writing the fields  
        csvwriter.writerow(fields)  
            
        # writing the data rows  
        csvwriter.writerows(rows) 

def check_same(orderId, phone, email):
    result = []
    same_order = contacts.loc[( (contacts["Phone"] != "") & (contacts["Phone"] == phone) ) | ( (contacts["Email"] != "") & (contacts["Email"] == email) ) | ( (contacts["OrderId"] != "") & (contacts["OrderId"] == orderId))]
    for order in same_order.iterrows():
        result.append([order[0], order[1]])
    
    return result

def get_children(current_ticket, parent_ticket):   
    # print(current_ticket) 
    # print("\n\n\n")
    children = check_same(current_ticket["OrderId"], current_ticket["Phone"], current_ticket["Email"])
    count = len(children)
    finalChildren = []
    currentParents = parent_ticket
    currentParents.append(current_ticket["Id"])
    contactCount = []
    # print("parent ticket:", current_ticket)
    # print("dict",resultDict)

    #base case
    if count == 1:
        finalChildren.append(current_ticket["Id"])
        contactCount.append(current_ticket['Contacts'])

    else:
        # print("I am", current_ticket["Id"])
        # print("My children are", children)
        for child in children:
            if current_ticket["Id"] == child[0]:
                grandchildren = [current_ticket["Id"]]
                contactCount.append(current_ticket['Contacts'])
            else:
                if child[0] not in currentParents:
                    grandchildren = get_children(child[1], currentParents)[0]
                    contactCount += get_children(child[1], currentParents)[1]   
                else:
                    grandchildren = []
                
            finalChildren += grandchildren
            contacts.drop(contacts.index[[int(child[0])]], axis=0, inplace=True)
    

    return [finalChildren, contactCount]

def main():
    # while len(contacts) > 0:

    while len(contacts) > 0:
        # print("\r\r")
        # print("current ticket", i)
        ticket = contacts.iloc[0]
        children = get_children(ticket, [])
        finalChildren = children[0]
        contactCount = sum(children[1]) 
        print(finalChildren)
        print(contactCount)
        # print("finalChildren:", finalChildren )

        for finalChild in finalChildren:
            resultDict[finalChild] = [finalChildren, contactCount]
    

        



main()
orderedDict = collections.OrderedDict(sorted(resultDict.items()))
# print("over here!", orderedDict[1])
# print(orderedDict)
write_to_csv(orderedDict)


    

